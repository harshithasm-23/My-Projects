# server.py
from flask import Flask, request, jsonify
from flask_cors import CORS
import random

app = Flask(__name__)
CORS(app)

@app.route("/")
def home():
    return "✅ Flask backend is running"

@app.route("/predict", methods=["GET", "POST"])
def predict():
    if request.method == "GET":
        return jsonify({
            "info": "POST JSON like {\"location\": \"Sira\"} to get predictions"
        })

    # Parse input from frontend
    data = request.get_json() or {}
    location = data.get("location", "Unknown")

    # List of diseases
    diseases = ["Acute Diarrhoeal Disease", "Dengue", "Chikungunya", "Cholera", "Malaria"]
    disease = random.choice(diseases)

    # Generate realistic actual case counts per disease
    disease_base_cases = {
        "Acute Diarrhoeal Disease": (300, 1200),
        "Dengue": (200, 800),
        "Chikungunya": (100, 500),
        "Cholera": (50, 300),
        "Malaria": (150, 600)
    }

    actual_case = random.randint(*disease_base_cases[disease])

    # Predicted cases within ±15% range of actual
    variation = random.uniform(0.9, 1.15)
    predicted_case = int(actual_case * variation)

    # Simple risk calculation
    risk_level = (
        "High" if predicted_case > actual_case * 1.1
        else "Moderate" if predicted_case > actual_case * 0.95
        else "Low"
    )

    # Outbreak logic: if predicted cases exceed 1.2× actual → Yes
    outbreak = "Yes" if predicted_case > actual_case * 1.2 else "No"

    # Recovery rate based on disease (mock realistic values)
    recovery_rates = {
        "Acute Diarrhoeal Disease": random.uniform(90, 98),
        "Dengue": random.uniform(85, 95),
        "Chikungunya": random.uniform(80, 90),
        "Cholera": random.uniform(88, 96),
        "Malaria": random.uniform(85, 97)
    }

    recovery_rate = round(recovery_rates[disease], 1)

    # Build final JSON response
    response = {
        "location": location,
        "disease": disease,
        "predicted_case": predicted_case,
        "actual_case": actual_case,
        "recovery_rate": recovery_rate,
        "risk_level": risk_level,
        "outbreak": outbreak
    }

    return jsonify(response)


if __name__ == "__main__":
    print("🚀 Flask server running on http://127.0.0.1:5000")
    app.run(host="127.0.0.1", port=5000, debug=True)
