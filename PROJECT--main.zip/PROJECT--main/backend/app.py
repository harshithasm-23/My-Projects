from flask import Flask, jsonify, request
import pandas as pd
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Allow connection from frontend

# ==========================
# Load your datasets
# ==========================
# Original dataset (actual cases)
original_df = pd.read_csv("C:/Users/kavya/OneDrive/Documents/Desktop/Outbreak/backend/Final_data.csv")

# Model predictions dataset
pred_df = pd.read_csv("C:/Users/kavya/OneDrive/Documents/Desktop/Outbreak/backend/cnn11_predictions_cases_with_outbreak.csv")

# Standardize column names
original_df.columns = original_df.columns.str.lower()
pred_df.columns = pred_df.columns.str.lower()

# Try to merge on common columns (e.g., 'disease' and 'place' or 'state')
common_cols = list(set(original_df.columns) & set(pred_df.columns))
if "disease" in common_cols and "state" in common_cols:
    merged_df = pd.merge(original_df, pred_df, on=["disease", "state"], how="outer")
else:
    merged_df = pred_df.copy()

# Compute outbreak column if not present
if "outbreak" not in merged_df.columns:
    merged_df["outbreak"] = abs(merged_df["case"] - merged_df["predicted_case"]) < 50
    merged_df["outbreak"] = merged_df["outbreak"].apply(lambda x: "Yes" if x else "No")

# ==========================
# API: Fetch latest summary
# ==========================
@app.route("/api/latest", methods=["GET"])
def latest_data():
    """Return latest case and outbreak info for a given location or disease"""
    query = request.args.get("place", "").lower()
    disease = request.args.get("disease", "").lower()

    df = merged_df.copy()

    if query:
        df = df[df.apply(lambda row: query in str(row.to_dict()).lower(), axis=1)]
    if disease:
        df = df[df["disease"].str.lower().str.contains(disease)]

    if df.empty:
        return jsonify({"error": "No data found"}), 404

    latest = df.iloc[-1].to_dict()
    result = {
        "place": latest.get("state", "Unknown"),
        "disease": latest.get("disease", "Unknown"),
        "actual_case": latest.get("case", None),
        "predicted_case": latest.get("predicted_case", None),
        "outbreak": latest.get("outbreak", "No"),
    }
    return jsonify(result)

# ==========================
# API: Get trend data
# ==========================
@app.route("/api/trend", methods=["GET"])
def get_trend():
    """Return trend for a given disease"""
    disease = request.args.get("disease", "").lower()
    if not disease:
        return jsonify({"error": "Please provide a disease"}), 400

    df = merged_df[merged_df["disease"].str.lower() == disease]
    if df.empty:
        return jsonify({"error": "No data for given disease"}), 404

    # Take top 10 by date or index (if available)
    trend_df = df.tail(10)[["case", "predicted_case", "outbreak"]]
    trend = trend_df.to_dict(orient="records")
    return jsonify({"disease": disease, "trend": trend})

# ==========================
# Run Flask
# ==========================
if __name__ == "__main__":
    app.run(debug=True)
