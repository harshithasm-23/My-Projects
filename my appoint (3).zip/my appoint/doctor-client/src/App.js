import React, { useEffect, useState } from 'react';
import './App.css';

const App = () => {
  const [appointments, setAppointments] = useState([]);
  const [formData, setFormData] = useState({
    patientName: '',
    doctorName: '',
    date: '',
    time: '',
    reason: ''
  });
  const [editAppt, setEditAppt] = useState(null);
  const [loggedIn, setLoggedIn] = useState(false);
  const [loginData, setLoginData] = useState({ username: '', password: '' });

  const fetchAppointments = () => {
    fetch('http://localhost:4000/appointments')
      .then(res => res.json())
      .then(data => setAppointments(data));
  };

  useEffect(() => {
    if (loggedIn) fetchAppointments();
  }, [loggedIn]);

  const handleChange = (e) => {
    const { name, value } = e.target;
    const target = editAppt ? editAppt : formData;
    const updated = { ...target, [name]: value };
    editAppt ? setEditAppt(updated) : setFormData(updated);
  };

  const handleLoginChange = (e) => {
    const { name, value } = e.target;
    setLoginData({ ...loginData, [name]: value });
  };

  const handleLogin = () => {
    if (loginData.username === 'admin' && loginData.password === 'admin') {
      setLoggedIn(true);
    } else {
      alert('Invalid credentials');
    }
  };

  const submitAppointment = () => {
    fetch('http://localhost:4000/appointments', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    }).then(() => {
      setFormData({ patientName: '', doctorName: '', date: '', time: '', reason: '' });
      fetchAppointments();
    });
  };

  const updateAppointment = () => {
    fetch(`http://localhost:4000/appointments/${editAppt._id}`, {
      method: 'PUT',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(editAppt)
    }).then(() => {
      setEditAppt(null);
      fetchAppointments();
    });
  };

  const deleteAppointment = (id) => {
    if (window.confirm('Are you sure?')) {
      fetch(`http://localhost:4000/appointments/${id}`, {
        method: 'DELETE'
      }).then(() => fetchAppointments());
    }
  };

  const renderInput = (name, label, type = 'text') => (
    <div>
      <label>{label}</label><br />
      <input
        type={type}
        name={name}
        value={editAppt ? editAppt[name] : formData[name]}
        onChange={handleChange}
      />
    </div>
  );

  if (!loggedIn) {
    return (
      <div className="container">
        <h1>Login</h1>
        <input
          type="text"
          name="username"
          placeholder="Username"
          value={loginData.username}
          onChange={handleLoginChange}
        />
        <input
          type="password"
          name="password"
          placeholder="Password"
          value={loginData.password}
          onChange={handleLoginChange}
        />
        <button onClick={handleLogin}>Login</button>
      </div>
    );
  }

  return (
    <div className="container">
      <h1>Doctor Appointment Booking</h1>

      <div className="form">
        {renderInput('patientName', 'Patient Name')}
        {renderInput('doctorName', 'Doctor Name')}
        {renderInput('date', 'Date', 'date')}
        {renderInput('time', 'Time', 'time')}
        {renderInput('reason', 'Reason')}

        <button onClick={editAppt ? updateAppointment : submitAppointment}>
          {editAppt ? 'Update Appointment' : 'Book Appointment'}
        </button>
      </div>

      <h2>Appointments</h2>
      <table>
        <thead>
          <tr>
            <th>Patient</th>
            <th>Doctor</th>
            <th>Date</th>
            <th>Time</th>
            <th>Reason</th>
            <th>Actions</th>
          </tr>
        </thead>
        <tbody>
          {appointments.map(appt => (
            <tr key={appt._id}>
              <td>{appt.patientName}</td>
              <td>{appt.doctorName}</td>
              <td>{appt.date}</td>
              <td>{appt.time}</td>
              <td>{appt.reason}</td>
              <td>
                <button onClick={() => setEditAppt(appt)}>Edit</button>
                <button onClick={() => deleteAppointment(appt._id)}>Delete</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default App;
